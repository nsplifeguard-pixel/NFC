# web/RUN-WEB.py
from flask import Flask, render_template, request, jsonify
import subprocess
import threading
import os
import sys
import webbrowser
import time

app = Flask(__name__)

# ตัวแปร Global สำหรับเก็บ Log
output_logs = []

# เก็บ process พื้นหลังที่กำลังทำงานอยู่
running_process = None

# โฟลเดอร์ปัจจุบัน
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROGRAM_DIR = os.path.abspath(os.path.join(BASE_DIR, "..", "program"))

def get_script_path(mode):
    if mode == "fast":
        filename = "SMS-Fast.py"
    elif mode == "super":
        filename = "SMS-Super.py"
    else:
        filename = "SMS-Slow.py"
    return os.path.join(PROGRAM_DIR, filename)

def run_script(script_path, phone, count):
    global output_logs, running_process
    try:
        output_logs.clear()
        output_logs.append(f"[*] เริ่มรันไฟล์: {script_path}")
        output_logs.append(f"[*] เป้าหมายเบอร์: {phone}, จำนวน: {count}")

        process = subprocess.Popen(
            [sys.executable, "-u", script_path],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            cwd=PROGRAM_DIR
        )
        running_process = process

        try:
            input_str = f"{phone}\n{count}\n"
            process.stdin.write(input_str)
            process.stdin.flush()
        except Exception as e:
            output_logs.append(f"[!] Error sending input: {e}")

        while True:
            line = process.stdout.readline()
            if not line and process.poll() is not None:
                break
            if line:
                output_logs.append(line.strip())

        stderr = process.stderr.read()
        if stderr:
            output_logs.append(f"[!] Error: {stderr}")

        output_logs.append("[*] ทำงานเสร็จสิ้น")
        running_process = None

    except Exception as e:
        output_logs.append(f"[!] System Error: {e}")
        running_process = None

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/run", methods=["POST"])
def run():
    data = request.json
    phone = data.get("phone")
    count = data.get("count")
    mode = data.get("mode")

    if not phone or not count:
        return jsonify({"status": "error", "message": "ต้องใส่ข้อมูลให้ครบ!"})

    script_path = get_script_path(mode)

    if not os.path.exists(script_path):
        return jsonify({"status": "error", "message": f"ไม่พบไฟล์ {script_path} \n(กรุณาเช็คว่ามีไฟล์ในโฟลเดอร์ program หรือยัง)"})

    threading.Thread(target=run_script, args=(script_path, phone, count)).start()

    return jsonify({"status": "success", "message": f"เริ่มรันโหมด {mode.upper()} แล้ว!"})

@app.route("/get_logs")
def get_logs():
    return jsonify(output_logs)

@app.route("/stop_fire", methods=["POST"])
def stop_fire():
    """ฆ่า process พื้นหลัง (SMS script) แต่ Flask ยังทำงานต่อ"""
    global running_process, output_logs
    try:
        if running_process and running_process.poll() is None:
            running_process.kill()
            running_process.wait()
            running_process = None
            output_logs.append("[!] หยุดยิงแล้ว — process ถูกฆ่าเรียบร้อย")
            return jsonify({"status": "success", "message": "หยุดยิงเรียบร้อย"})
        else:
            return jsonify({"status": "info", "message": "ไม่มี process ที่กำลังทำงานอยู่"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})

@app.route("/shutdown", methods=["POST"])
def shutdown():
    """ปิดระบบทั้งหมด — ฆ่า background process และ Flask server"""
    global running_process, output_logs
    is_termux = "ANDROID_ROOT" in os.environ

    def do_shutdown():
        time.sleep(0.5)  # รอให้ response ส่งกลับก่อน

        # ฆ่า background process ก่อน
        if running_process and running_process.poll() is None:
            try:
                running_process.kill()
                running_process.wait()
            except Exception:
                pass

        if is_termux:
            # Termux: ฆ่า session นี้ → clear → แสดง motd
            # Chrome ปิดหน้าเว็บฝั่ง JS (window.close()) แล้ว user กลับมาดู Termux เอง
            subprocess.Popen(["bash", "-c", "kill $PPID; clear; cat $PREFIX/etc/motd"])
        else:
            # Windows: เคลียร์หน้าจอ CMD แล้วปิดแค่ Python — CMD/PowerShell ยังอยู่ครบ
            subprocess.Popen("cls", shell=True)
            os.kill(os.getpid(), 9)

    threading.Thread(target=do_shutdown, daemon=True).start()
    return jsonify({"status": "success", "message": "กำลังปิดระบบ..."})

# ฟังก์ชันเปิดเว็บอัตโนมัติ
def open_browser():
    url = "http://127.0.0.1:8080"
    if "ANDROID_ROOT" in os.environ:
        try:
            subprocess.run(["termux-open-url", url])
            print(f"[*] เปิดเว็บอัตโนมัติใน Termux: {url}")
        except FileNotFoundError:
            print("[!] ไม่พบคำสั่ง termux-open-url (ลองพิมพ์ pkg install termux-tools)")
    else:
        webbrowser.open(url)
        print(f"[*] เปิดเว็บอัตโนมัติ: {url}")

if __name__ == "__main__":
    if os.environ.get('WERKZEUG_RUN_MAIN') != 'true':
        threading.Timer(0.1, open_browser).start()
# กำหนด ip และ port
    app.run(host="0.0.0.0", port=8080, debug=True)
